![](https://raw.githubusercontent.com/Matthewpco/WP-Plugin-Webp-Image-Converter/main/webp-img-converter.png)

# Webp Image Converter

<br>

## 🙋‍♂️ Introduction

- Wordpress plugin that adds a new submenu under tools with a form to either enter a url of an image to convert or upload an image and convert to webp. Added functionality to scan through media library and convert all images at once.

<br>

## 📜 Features

- HTML
- CSS
- PHP
- WordPress Plugin

  <br>
  
